import "./Expenses.css";
import ExpenseItems from "./ExpenseItems";
import Card from "../UI/Card";
import React from "react";
const Expenses = (props) => {
  return (
    <Card className="expenses">
      {
        props.item.map(
          expense =>(  //arrow function that returns operation to var expense
            <ExpenseItems
            key={expense.id}   //for any component to be looped, always use any key for instance, it improves render performance.
            date={expense.date}
            title={expense.title}
            amount={expense.amount}
            />

          )
        )
      }

    </Card>
  );
};
export default Expenses;
