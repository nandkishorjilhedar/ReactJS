import React from "react";
import './NewExpense.css';
import ExpenseForm from "./ExpenseForm";
const NewExpense = (props) =>{
    const saveExpenseDataHandler = (enteredExpenseData) => {
        const expenseData = {
            ...enteredExpenseData,
            id: Math.random().toString(),
         }
         props.onAddExpense (expenseData);
     //   console.log(enteredExpenseData,expenseData)
    }; //function to receive data from child, ExpenseForm.js, there sent through props parameter

    return(  //similar to sending data through props, except that it has to be received in function here, saveExpeneseDataHandler, for sending we used to use variable or object etc. here function is used to receive
        <div className="new-expense">
            <ExpenseForm onSaveExpenseData = {saveExpenseDataHandler}/> 
        </div>
    );


}

export default NewExpense;