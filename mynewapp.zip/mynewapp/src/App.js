import Expenses from "./components/Expenses/Expenses";
import React, {useState,useEffect} from "react";
import NewExpense from "./components/ExpensesForm/NewExpense";

let DUMMY_EXPENSE = [
  {
    id: "e1",
    title: "Car Insruance",
    amount: 7500,
    date: new Date(2022, 4, 4),
  },
  {
    id: "e2",
    title: "School Fees",
    amount: 3000,
    date: new Date(2022, 5, 5),
  },

  {
    id: "e3",
    title: "Electricity Bill",
    amount: 1280,
    date: new Date(2022, 6, 6),
  },

  {
    id: "e4",
    title: "Books",
    amount: 650,
    date: new Date(2022, 6, 12),
  },
];

const App = () => {
  //   let expenseDate = new Date(2022, 4, 25);
  //   let expenseTitle = "Car Insurance";
  //   let expenseAmount = 7500;

  const [expenses, setExpenses] = useState(DUMMY_EXPENSE);

  /* API Code below
      function fetchData(){
        fetch('www.sampleapi.com').then(
          response =>{    return response.json();     }    )
          .then (   data =>{ setExpenses.(data);      }    );

      }
      
      useEffect( ()=>{ //first parameter function containing fetch
         fetchData(); 
        }, 

        //second parameter blank array
        []
      );     
   * */
   
  //follwoing is data receiver function from NewExpense.js
  const addExpenesHandler = (expense) =>{
    //console.log(expense);
    const updatedExpense = [expense,...expenses];
    setExpenses(updatedExpense);

    /* API Code
     fetch('www.api.com',{
      method : 'POST',
      body : JSON.stringify(expense),
      headers : { 'content-type' :   'application/json'}
      }). then(
         response = >{
          fetchData();
         }
      );
      

    */
  };

  return (
    <div>
     <NewExpense onAddExpense = {addExpenesHandler}/>
      <Expenses item={expenses} />
    </div>
  );
};

export default App;
