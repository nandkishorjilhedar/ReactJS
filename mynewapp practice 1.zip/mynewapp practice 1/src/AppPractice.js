import "./AppPractice.css";
import SubComponent from "./components/SubComponent";
export default function AppPractice() {
  return (
    <div className="app-container">
      <h3>First Component</h3>
      <p>This is a p tag</p>
      <SubComponent/>
    </div>
  );
}
