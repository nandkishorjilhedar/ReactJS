import "./ExpenseItems.css";
import ExpenseDate from "./ExpenseDate";
import Card from "../UI/Card";
import React, {useState} from "react";
const ExpenseItems = (props) => {
  const [newTitle, setNewTitle]=useState("")
  const [title, setTitle]=useState(props.title);  //returns array containing 2 values- a variable to change and function to perform this change.
  const clickHandler=()=>{
    setTitle(newTitle)
    //alert('clicked');
   
  }

  const changeHandler =(event)=>{
    setNewTitle(event.target.value);
  }
  return (
    <Card className="expense-item">
      <ExpenseDate date={props.date} />
      <div className="expense-item-desc ">
        <h2>{title}</h2>
        <div className="expense-item-price">Rs {props.amount}</div>
      </div>
      <input type="text" value={newTitle} onChange={changeHandler}/>
      <button onClick={clickHandler}>Change Title</button>
    </Card>
  );
};
export default ExpenseItems;
