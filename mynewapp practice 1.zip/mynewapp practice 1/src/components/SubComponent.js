import "./SubComponent.css";

export default function SubComponent() {
  return (
  <p className="ptag">This is the first subcomponent</p>
  );
}
