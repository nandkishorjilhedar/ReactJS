import ReactDom from "react-dom";
import "./index.css";
import React from "react";
import App from './App';
//import AppPractice from "./AppPractice";
//import React from 'react';
//const root = ReactDom.createRoot(document.getElementById('root'));
/*root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);*/
//ReactDom.render(<h1>Hi</h1>, document.getElementById("root"));
ReactDom.render(<App/>, document.getElementById("root"));
