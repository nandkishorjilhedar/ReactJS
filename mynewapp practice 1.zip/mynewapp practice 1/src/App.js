import Expenses from "./components/Expenses/Expenses";
import React from "react";

const App = () => {
  //   let expenseDate = new Date(2022, 4, 25);
  //   let expenseTitle = "Car Insurance";
  //   let expenseAmount = 7500;

  let items = [
    {
      id: "e1",
      title: "Car Insruance",
      amount: 7500,
      date: new Date(2022, 4, 4),
    },
    {
      id: "e2",
      title: "School Fees",
      amount: 3000,
      date: new Date(2022, 5, 5),
    },

    {
      id: "e3",
      title: "Electricity Bill",
      amount: 1280,
      date: new Date(2022, 6, 6),
    },

    {
      id: "e4",
      title: "Books",
      amount: 650,
      date: new Date(2022, 6, 12),
    },
  ];
  return (
    <div>
      <h2>Lets Start</h2>
      <Expenses item={items} />
    </div>
  );
};

export default App;
